from flask import Flask, g
from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker
from bd import Base, User, Gnome, Achievement, init_db, get_session


def create_app():
    app = Flask(__name__)

    DATABASE_URI = 'sqlite:///gnome.db'
    engine = create_engine(DATABASE_URI, echo=True)
    Base.metadata.create_all(engine)
    session_factory = sessionmaker(bind=engine)
    Session = scoped_session(session_factory)

    @app.before_request
    def before_request():
        g.session = Session()

    @app.teardown_appcontext
    def teardown_request(exception=None):
        session = getattr(g, 'session', None)
        if session is not None:
            session.close()

    @app.route('/')
    def hello_world():
        return 'Hello World!'

    @app.route('/add_user')
    def add_user():
        session = g.session
        user = User(Username='art', Email='something@gmal.com', Password='thisispassword')
        session.add(user)
        session.commit()
        return f"User {user.Username} added."

    @app.route('/add_gnome')
    def add_gnome():
        session = g.session
        gnome = Gnome(Name='Gnome the Gnome', Description='The First out there', Location='just behind you',
                      Image='gnome1.png')
        session.add(gnome)
        session.commit()
        return f"Gnome {gnome.Name} added."

    @app.route('/add_achievement')
    def add_achievement():
        session = g.session
        achievement = Achievement(Name='first Step', Condition='complete the tutorial')
        session.add(achievement)
        session.commit()
        return f"Achievement {achievement.Name} added."


    @app.route('/list_users_and_gnomes')
    def list_users_and_gnomes():
        session = g.session
        users = session.query(User).all()
        gnomes = session.query(Gnome).all()

        users_info = '<br>'.join([f"User: {user.Username}, Email: {user.Email}" for user in users])
        gnomes_info = '<br>'.join(
            [f"Gnome: {gnome.Name}, Description: {gnome.Description}, Location: {gnome.Location}, Image: {gnome.Image}"
             for gnome in gnomes])

        return f"Users:<br>{users_info}<br><br>Gnomes:<br>{gnomes_info}"

    return app


if __name__ == '__main__':
    app = create_app()
    app.run()
